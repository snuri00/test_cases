from selenium import webdriver
from selenium.webdriver.common.by import By

def test_listing():
    driver = webdriver.Chrome()
    driver.get('https://flights-app.pages.dev/')

    from_input = driver.find_element(By.NAME, 'from')
    to_input = driver.find_element(By.NAME, 'to')
    search_button = driver.find_element(By.ID, 'search-button') 

    from_input.send_keys('Istanbul')
    to_input.send_keys('Los Angeles')

    search_button.click()

    flights = driver.find_elements(By.CSS_SELECTOR, 'div.flight-item') 
    flights_count = len(flights)

    found_text_element = driver.find_element(By.CSS_SELECTOR, 'div.found-items') 
    found_text = found_text_element.text
    assert found_text == f'Found {flights_count} items'

    driver.quit()