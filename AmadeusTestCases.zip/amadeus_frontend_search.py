from selenium import webdriver
from selenium.webdriver.common.by import By

def test_search_bug():
    driver = webdriver.Chrome()
    driver.get('https://flights-app.pages.dev/')

    from_input = driver.find_element(By.NAME, 'from')
    to_input = driver.find_element(By.NAME, 'to')

    from_input.send_keys('IST')
    to_input.send_keys('IST')

    assert from_input.get_attribute('value') == to_input.get_attribute('value')

    driver.quit()
