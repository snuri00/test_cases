import requests

def test_flights_api():
    url = 'https://flights-api.buraky.workers.dev/flights'
    response = requests.get(url)

    assert response.status_code == 200

    assert response.headers['Content-Type'] == 'application/json'

    flights = response.json()['data']
    for flight in flights:
        assert 'id' in flight and isinstance(flight['id'], int)
        assert 'from' in flight and isinstance(flight['from'], str)
        assert 'to' in flight and isinstance(flight['to'], str)
        assert 'date' in flight and isinstance(flight['date'], str)
